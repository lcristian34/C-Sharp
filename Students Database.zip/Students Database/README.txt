Try out the program installing the .exe file, or just run the project in visual studio.

Thanks!

� 2018 Christian Lara. All rights reserved.